<?php $__currentLoopData = $products->chunk(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productos): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
    <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
        <div class="col-sm-4">
            <div class="product-image-wrapper">
                <div class="single-products">
                        <div class="productinfo text-center">
                            <?php $__currentLoopData = $producto->imagenes->take(1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imagen): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                <img src="<?php echo e($imagen->rutaimagen); ?>" alt="" />
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            <h2>$ <?php echo e($producto->precio); ?></h2>
                            <p><?php echo e($producto->titulo); ?></p>
                            <a href="<?php echo e(route('product.anadiralcarro',['id' => $producto->id])); ?>" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Añadir al carro</a>
                        </div>
                        <div class="product-overlay">
                            <div class="overlay-content">
                                <h2>$ <?php echo e($producto->precio); ?></h2>
                                <p><?php echo e($producto->descripcion); ?></p>
                                <a href="<?php echo e(route('product.anadiralcarro',['id' => $producto->id])); ?>" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Añadir al carro</a>
                            </div>
                            <?php if($producto->condicion): ?>
                                <?php if($producto->condicion == 'Nuevo'): ?>
                                    <span class="label label-success pull-right"><?php echo e($producto->condicion); ?></span>
                                <?php endif; ?>
                            <?php endif; ?>
                            
                            <?php if($producto->oferta): ?>
                                <span class="label label-info pull-right">En oferta</span>
                            <?php endif; ?>
                            
                        </div>
                </div>
                <div class="choose">
                    <ul class="nav nav-pills nav-justified">
                        <li><a href="#"><i class="fa fa-plus-square"></i>Favoritos</a></li>
                        <li><a href="#"><i class="fa fa-plus-square"></i>Comparar</a></li>
                    </ul>
                </div>
                <div class="choose">
                    <a href="<?php echo e(route('product.productodetalle',['id' => $producto->id])); ?>" class="btn btn-primary btn-block">Ver detalle</a>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>